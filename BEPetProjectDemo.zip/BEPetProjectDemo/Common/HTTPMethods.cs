﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEPetProjectDemo
{
    public class HTTPMethods
    {
        public const string GET = "get";
        public const string POST = "post";
        public const string PUT = "put";
        public const string DELETE = "delete";
    }
}
