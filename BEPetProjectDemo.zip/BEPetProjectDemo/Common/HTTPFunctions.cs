﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEPetProjectDemo
{
    public class HTTPFunctions
    {
        public const string Get = "GetallPatients";
        public const string GetById = "GetPatientsById";
        public const string Create = "CreatePatient";
        public const string Update = "UpdatePatient";
        public const string Delete = "DeletePatient";
    }
}
